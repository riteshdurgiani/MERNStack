import React from "react";
import Base from "../core/Base";

const ManageCategories = () => {
  return (
    <Base>
      <h1 className="text-white">Your assignment</h1>
    </Base>
  );
};

export default ManageCategories;
