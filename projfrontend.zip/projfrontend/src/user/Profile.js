import React from 'react'
import Base from '../core/Base';





const Profile=()=> {
    return (
        <Base title="Profile Page">
            <h1>This is profile page </h1>
        </Base>
    )
}
export default Profile;