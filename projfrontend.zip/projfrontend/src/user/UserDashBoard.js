import React from 'react'
import Base from '../core/Base';





const UserDashBoard=()=> {
    return (
        <Base title="UserDashBoard">
            <h2> Please visit the home page for purchasing the items. </h2>
        </Base>
    )
}
export default UserDashBoard;