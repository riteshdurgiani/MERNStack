import React from 'react'

export default function App() {
  return (
    <div>
      <h1>Hello</h1>
    </div>
  )
}
